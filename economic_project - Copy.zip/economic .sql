-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2024 at 01:57 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `economic`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add category', 7, 'add_category'),
(26, 'Can change category', 7, 'change_category'),
(27, 'Can delete category', 7, 'delete_category'),
(28, 'Can view category', 7, 'view_category'),
(29, 'Can add product', 8, 'add_product'),
(30, 'Can change product', 8, 'change_product'),
(31, 'Can delete product', 8, 'delete_product'),
(32, 'Can view product', 8, 'view_product'),
(33, 'Can add cart', 9, 'add_cart'),
(34, 'Can change cart', 9, 'change_cart'),
(35, 'Can delete cart', 9, 'delete_cart'),
(36, 'Can view cart', 9, 'view_cart'),
(37, 'Can add wishlist', 10, 'add_wishlist'),
(38, 'Can change wishlist', 10, 'change_wishlist'),
(39, 'Can delete wishlist', 10, 'delete_wishlist'),
(40, 'Can view wishlist', 10, 'view_wishlist'),
(41, 'Can add order', 11, 'add_order'),
(42, 'Can change order', 11, 'change_order'),
(43, 'Can delete order', 11, 'delete_order'),
(44, 'Can view order', 11, 'view_order'),
(45, 'Can add order item', 12, 'add_orderitem'),
(46, 'Can change order item', 12, 'change_orderitem'),
(47, 'Can delete order item', 12, 'delete_orderitem'),
(48, 'Can view order item', 12, 'view_orderitem'),
(49, 'Can add profile', 13, 'add_profile'),
(50, 'Can change profile', 13, 'change_profile'),
(51, 'Can delete profile', 13, 'delete_profile'),
(52, 'Can view profile', 13, 'view_profile');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$150000$Z4mrZxXyD1ev$UxTexWN00wOTlpr/KMC9rvNyD3kE3rBVNO9I0pX0WYA=', '2024-04-18 16:26:22.251110', 1, 'admin', 'pyae', 'phyo', 'admin@gmail.com', 1, 1, '2024-02-12 10:21:01.023558'),
(2, 'pbkdf2_sha256$150000$x9SXDMchb6Rs$c3QriohIhtQm1i8Y+D8DXrtk7HtIPYfzi5GMB4NAJzM=', '2024-05-26 14:12:02.780695', 0, 'layaung', 'la', 'yaung', 'la25254678@gmail.com', 0, 1, '2024-02-12 11:19:35.464088'),
(3, 'pbkdf2_sha256$150000$ViR2C1tDPyt2$/yZT9zmYXwrPeB2EhLP4OGjz3wI3Lxvi8tyvxvptGws=', '2024-04-25 15:21:27.840159', 1, 'pyaephyo', 'pyae', 'phyo', 'pyae@gmail.com', 1, 1, '2024-04-25 15:20:54.158533');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2024-02-12 10:22:01.580399', '1', 'clothes', 1, '[{\"added\": {}}]', 7, 1),
(2, '2024-02-12 10:22:55.118495', '1', 'clothes', 1, '[{\"added\": {}}]', 8, 1),
(3, '2024-02-12 10:38:10.652196', '2', 'Juice', 1, '[{\"added\": {}}]', 7, 1),
(4, '2024-02-12 10:39:34.840054', '2', 'Orange juice', 1, '[{\"added\": {}}]', 8, 1),
(5, '2024-02-12 10:39:55.264380', '2', 'Orange juice', 2, '[{\"changed\": {\"fields\": [\"status\"]}}]', 8, 1),
(6, '2024-04-25 15:28:47.934293', '3', 'min min', 1, '[{\"added\": {}}]', 7, 3),
(7, '2024-04-25 15:29:19.076067', '3', 'Clothes', 2, '[{\"changed\": {\"fields\": [\"name\"]}}]', 7, 3),
(8, '2024-04-25 15:30:21.437447', '3', 'Style pine', 1, '[{\"added\": {}}]', 8, 3),
(9, '2024-04-25 15:31:13.123322', '4', 'Style pine', 1, '[{\"added\": {}}]', 7, 3),
(10, '2024-04-25 15:34:15.691834', '4', 'min min', 1, '[{\"added\": {}}]', 8, 3),
(11, '2024-04-25 15:36:52.172922', '16', '16 - layaung1668598', 3, '', 11, 3),
(12, '2024-04-25 15:36:52.176429', '15', '15 - layaung3861876', 3, '', 11, 3),
(13, '2024-04-25 15:36:52.179463', '14', '14 - layaung6689754', 3, '', 11, 3),
(14, '2024-04-25 15:36:52.183550', '13', '13 - layaung3426460', 3, '', 11, 3),
(15, '2024-04-25 15:36:52.186736', '12', '12 - layaung7120303', 3, '', 11, 3),
(16, '2024-04-25 15:36:52.186736', '11', '11 - layaung4445135', 3, '', 11, 3),
(17, '2024-04-25 15:36:52.192477', '10', '10 - layaung7596675', 3, '', 11, 3),
(18, '2024-04-25 15:36:52.194743', '9', '9 - layaung8015789', 3, '', 11, 3),
(19, '2024-04-25 15:36:52.195741', '8', '8 - layaung7848259', 3, '', 11, 3),
(20, '2024-04-25 15:36:52.200322', '7', '7 - layaung4756371', 3, '', 11, 3),
(21, '2024-04-25 15:36:52.202791', '6', '6 - layaung4186667', 3, '', 11, 3),
(22, '2024-04-25 15:36:52.203818', '5', '5 - layaung3251793', 3, '', 11, 3),
(23, '2024-04-25 15:36:52.203818', '4', '4 - layaung4896351', 3, '', 11, 3),
(24, '2024-04-25 15:36:52.203818', '3', '3 - layaung3212083', 3, '', 11, 3),
(25, '2024-04-25 15:36:52.213388', '2', '2 - layaung5802151', 3, '', 11, 3),
(26, '2024-04-25 15:36:52.215433', '1', '1 - layaung2858910', 3, '', 11, 3);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session'),
(9, 'store', 'cart'),
(7, 'store', 'category'),
(11, 'store', 'order'),
(12, 'store', 'orderitem'),
(8, 'store', 'product'),
(13, 'store', 'profile'),
(10, 'store', 'wishlist');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2024-02-12 10:20:26.123050'),
(2, 'auth', '0001_initial', '2024-02-12 10:20:26.246252'),
(3, 'admin', '0001_initial', '2024-02-12 10:20:26.576567'),
(4, 'admin', '0002_logentry_remove_auto_add', '2024-02-12 10:20:26.752136'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2024-02-12 10:20:26.778245'),
(6, 'contenttypes', '0002_remove_content_type_name', '2024-02-12 10:20:26.902983'),
(7, 'auth', '0002_alter_permission_name_max_length', '2024-02-12 10:20:26.969698'),
(8, 'auth', '0003_alter_user_email_max_length', '2024-02-12 10:20:27.010987'),
(9, 'auth', '0004_alter_user_username_opts', '2024-02-12 10:20:27.035956'),
(10, 'auth', '0005_alter_user_last_login_null', '2024-02-12 10:20:27.150660'),
(11, 'auth', '0006_require_contenttypes_0002', '2024-02-12 10:20:27.158268'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2024-02-12 10:20:27.178887'),
(13, 'auth', '0008_alter_user_username_max_length', '2024-02-12 10:20:27.205811'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2024-02-12 10:20:27.233092'),
(15, 'auth', '0010_alter_group_name_max_length', '2024-02-12 10:20:27.256706'),
(16, 'auth', '0011_update_proxy_permissions', '2024-02-12 10:20:27.276461'),
(17, 'sessions', '0001_initial', '2024-02-12 10:20:27.312921'),
(18, 'store', '0001_initial', '2024-02-12 10:20:27.402575'),
(19, 'store', '0002_cart', '2024-02-12 10:20:27.511594'),
(20, 'store', '0003_user', '2024-02-12 10:20:27.665924'),
(21, 'store', '0004_auto_20240207_1715', '2024-02-12 10:20:27.793246'),
(22, 'store', '0005_auto_20240208_2033', '2024-02-12 10:20:27.918073'),
(23, 'store', '0006_auto_20240208_2041', '2024-02-12 10:20:27.970468'),
(24, 'store', '0007_remove_booklist_user', '2024-02-12 10:20:28.038283'),
(25, 'store', '0008_auto_20240208_2051', '2024-02-12 10:20:28.067399'),
(26, 'store', '0009_auto_20240208_2059', '2024-02-12 10:20:28.141783'),
(27, 'store', '0010_auto_20240210_0004', '2024-02-12 10:20:28.243318'),
(28, 'store', '0011_auto_20240210_0026', '2024-02-12 10:20:28.353208'),
(29, 'store', '0012_auto_20240212_1620', '2024-02-12 10:20:28.399771'),
(30, 'store', '0013_auto_20240212_1622', '2024-02-12 10:20:28.477432'),
(31, 'store', '0014_auto_20240212_1632', '2024-02-12 10:20:28.561880'),
(32, 'store', '0015_profile', '2024-02-12 10:53:25.295988');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('508jvnfmql89h5t6qm6o2im0tth7osn4', 'MThlZDkzMjBiNjYxNzg2ZTkzNzgzYTk3MjdhMDlmYzQxMjc2YTYzMTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlNTI4ZjliODU2NzAxNjRmNTQ1YjcwM2U3Yzk0MzM4NDRiMmIyM2Q0In0=', '2024-05-06 05:15:20.198927'),
('69xidy7cvkqtqxd116mhyul720on5knk', 'ZTQ5ZjZkMzQwODVmNGViZGMzN2NmNDIzYzk4MDAxZjU5MTE5MGEzZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNmU0OTZjZGMzZjMwNWUzMDk4MDJmZTQ0MDI3NzgzODM2NzdhZmQzIn0=', '2024-02-27 15:15:12.561766'),
('8jb25h8ls721xt6gsmv0xbncjem0snhl', 'MThlZDkzMjBiNjYxNzg2ZTkzNzgzYTk3MjdhMDlmYzQxMjc2YTYzMTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlNTI4ZjliODU2NzAxNjRmNTQ1YjcwM2U3Yzk0MzM4NDRiMmIyM2Q0In0=', '2024-05-08 04:24:19.013042'),
('ipsawez4zropagusuppu4705mmppdvd8', 'OTBiZjA0YWQzNTE5NWJmYzcyODNjMGVmMDFiMzExMDJlNDBmNGI5Zjp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhZDk1NzhiNDkzZTI0ZjcwN2U2Yzc4YzAzMjI0ZDA4NDFhOTc5YjBkIn0=', '2024-05-09 15:21:27.848532'),
('kg0oo13t49bzruhdlj94y8cig4bb56bv', 'MThlZDkzMjBiNjYxNzg2ZTkzNzgzYTk3MjdhMDlmYzQxMjc2YTYzMTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlNTI4ZjliODU2NzAxNjRmNTQ1YjcwM2U3Yzk0MzM4NDRiMmIyM2Q0In0=', '2024-05-11 14:26:23.484969'),
('kwk74p2ync3wc272i8grq92i52b0wl7w', 'MThlZDkzMjBiNjYxNzg2ZTkzNzgzYTk3MjdhMDlmYzQxMjc2YTYzMTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlNTI4ZjliODU2NzAxNjRmNTQ1YjcwM2U3Yzk0MzM4NDRiMmIyM2Q0In0=', '2024-06-09 14:12:02.785136'),
('nr3j7moig6x51b4yeqykec7qhg2qfwfu', 'ZTQ5ZjZkMzQwODVmNGViZGMzN2NmNDIzYzk4MDAxZjU5MTE5MGEzZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNmU0OTZjZGMzZjMwNWUzMDk4MDJmZTQ0MDI3NzgzODM2NzdhZmQzIn0=', '2024-05-02 16:26:22.251110'),
('rd1ue3pkyb43cilkjyd91kwpryj1583n', 'ZTQ5ZjZkMzQwODVmNGViZGMzN2NmNDIzYzk4MDAxZjU5MTE5MGEzZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNmU0OTZjZGMzZjMwNWUzMDk4MDJmZTQ0MDI3NzgzODM2NzdhZmQzIn0=', '2024-03-16 13:14:41.899850'),
('ylkyn2ijyfjo455c32qy70i0tpudumwp', 'ZTQ5ZjZkMzQwODVmNGViZGMzN2NmNDIzYzk4MDAxZjU5MTE5MGEzZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNmU0OTZjZGMzZjMwNWUzMDk4MDJmZTQ0MDI3NzgzODM2NzdhZmQzIn0=', '2024-03-16 13:32:19.797904');

-- --------------------------------------------------------

--
-- Table structure for table `store_cart`
--

CREATE TABLE `store_cart` (
  `id` int(11) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_cart`
--

INSERT INTO `store_cart` (`id`, `product_qty`, `created_at`, `product_id`, `user_id`) VALUES
(17, 5, '2024-03-02', 2, 1),
(21, 1, '2024-04-25', 1, 3),
(22, 1, '2024-04-25', 2, 3),
(24, 1, '2024-05-26', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `store_category`
--

CREATE TABLE `store_category` (
  `id` int(11) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `description` longtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  `trending` tinyint(1) NOT NULL,
  `meta_title` varchar(150) NOT NULL,
  `meta_keywords` varchar(150) NOT NULL,
  `meta_description` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_category`
--

INSERT INTO `store_category` (`id`, `slug`, `name`, `image`, `description`, `status`, `trending`, `meta_title`, `meta_keywords`, `meta_description`, `created_at`) VALUES
(1, 'clothes', 'clothes', 'uploads/20240212165201FB_IMG_1681883801394.jpg', 'Clothes for people wear.', 0, 0, 'Clothes for people wear.', 'Clothes for people wear.', 'Clothes for people wear.', '2024-02-12 10:22:01.580399'),
(2, 'Juice', 'Juice', 'uploads/20240212170810mango-frooti.jpg', 'food for people.', 0, 0, 'food for people.', 'food for people.', 'food for people.', '2024-02-12 10:38:10.650855'),
(3, 'Foods', 'Clothes', 'uploads/20240425215847FB_IMG_1681883806149.jpg', 'jkk', 0, 0, 'oioi', 'joi', 'jkkj', '2024-04-25 15:28:47.932688'),
(4, 'clothes', 'Style pine', 'uploads/20240425220113FB_IMG_1681883808143.jpg', 'kkKL', 0, 0, 'LKALKA', 'AKAK', 'KAKJAKJ', '2024-04-25 15:31:13.117618');

-- --------------------------------------------------------

--
-- Table structure for table `store_order`
--

CREATE TABLE `store_order` (
  `id` int(11) NOT NULL,
  `fname` varchar(150) NOT NULL,
  `lname` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `address` longtext NOT NULL,
  `city` varchar(150) NOT NULL,
  `state` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `pincode` varchar(150) NOT NULL,
  `total_price` double NOT NULL,
  `payment_mode` varchar(150) NOT NULL,
  `payment_id` varchar(250) DEFAULT NULL,
  `status` varchar(150) NOT NULL,
  `message` longtext DEFAULT NULL,
  `tracking_no` varchar(150) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `user_id` int(11) NOT NULL,
  `update_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_order`
--

INSERT INTO `store_order` (`id`, `fname`, `lname`, `email`, `phone`, `address`, `city`, `state`, `country`, `pincode`, `total_price`, `payment_mode`, `payment_id`, `status`, `message`, `tracking_no`, `created_at`, `user_id`, `update_at`) VALUES
(17, 'la', 'yaung', 'la25254678@gmail.com', '09252558602', 'Yangon Thamwe Ease Horse Rose Kyaung Shae Bus Stop', 'YANGON', 'Tamwe', 'Myanmar', '90', 3500, 'COD', NULL, 'Pending', NULL, 'layaung2756800', '2024-04-27 14:28:37.244296', 2, '2024-04-27 14:28:37.244296');

-- --------------------------------------------------------

--
-- Table structure for table `store_orderitem`
--

CREATE TABLE `store_orderitem` (
  `id` int(11) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_orderitem`
--

INSERT INTO `store_orderitem` (`id`, `price`, `quantity`, `order_id`, `product_id`) VALUES
(19, 3500, 1, 17, 1);

-- --------------------------------------------------------

--
-- Table structure for table `store_product`
--

CREATE TABLE `store_product` (
  `id` int(11) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `product_image` varchar(100) DEFAULT NULL,
  `small_description` varchar(250) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `orginal_price` double NOT NULL,
  `selling_price` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  `trending` tinyint(1) NOT NULL,
  `tag` varchar(150) NOT NULL,
  `nota_title` varchar(150) NOT NULL,
  `nota_keywords` varchar(150) NOT NULL,
  `nota_description` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_product`
--

INSERT INTO `store_product` (`id`, `slug`, `name`, `product_image`, `small_description`, `quantity`, `description`, `orginal_price`, `selling_price`, `status`, `trending`, `tag`, `nota_title`, `nota_keywords`, `nota_description`, `created_at`, `category_id`) VALUES
(1, 'clothes', 'clothes', 'uploads/20240212165255FB_IMG_1681883826097.jpg', 'Clothes for people wear.', 22, 'Clothes for people wear.', 5000, 3500, 0, 1, 'Clothes for people wear.', 'Clothes for people wear.', 'Clothes for people wear.', 'Clothes for people wear.', '2024-02-12 10:22:55.110863', 1),
(2, 'Juice', 'Orange juice', 'uploads/20240212170934Orange-Juice-1-of-1.jpeg', 'food for people.', 77, 'food for people.', 4000, 3500, 0, 1, 'Juice', 'food for people.', 'food for people.', 'food for people.', '2024-02-12 10:39:34.836523', 2),
(3, 'clothes', 'Style pine', 'uploads/20240425220021FB_IMG_1681883808143.jpg', 'Food for people eate.', 22, 'ioaakjja', 2882, 22, 0, 0, 'ioq', 'klaa', 'klkaka', 'klklkla', '2024-04-25 15:30:21.433413', 1),
(4, 'clothes', 'min min', 'uploads/20240425220415FB_IMG_1681883810646.jpg', 'Food for people eate.', 78, 'LKlaklkalk', 234, 34, 0, 1, 'ioq', 'klaa', 'klkaka', 'ss', '2024-04-25 15:34:15.689838', 4);

-- --------------------------------------------------------

--
-- Table structure for table `store_profile`
--

CREATE TABLE `store_profile` (
  `id` int(11) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` longtext NOT NULL,
  `city` varchar(150) NOT NULL,
  `state` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `pincode` varchar(150) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_profile`
--

INSERT INTO `store_profile` (`id`, `phone`, `address`, `city`, `state`, `country`, `pincode`, `created_at`, `user_id`) VALUES
(1, '09252558602', 'Yangon Thamwe Ease Horse Rose Kyaung Shae Bus Stop', 'YANGON', 'Tamwe', 'Myanmar', '90', '2024-02-12 11:20:53.929339', 2),
(2, '0992882', 'YANGON ', 'Yangon', 'Tamwe', 'Yangon', '2344', '2024-03-02 13:24:55.968726', 1),
(3, '092828282828', 'Yangon Ease Horse Road Kyaung Shae Bus Stop', 'Yangon', 'akka', 'Yangon', '8893', '2024-04-25 15:23:30.859895', 3);

-- --------------------------------------------------------

--
-- Table structure for table `store_wishlist`
--

CREATE TABLE `store_wishlist` (
  `id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_wishlist`
--

INSERT INTO `store_wishlist` (`id`, `created_at`, `product_id`, `user_id`) VALUES
(2, '2024-02-13', 2, 2),
(4, '2024-03-02', 2, 1),
(6, '2024-04-25', 2, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `store_cart`
--
ALTER TABLE `store_cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_cart_product_id_b219c080_fk_store_product_id` (`product_id`),
  ADD KEY `store_cart_user_id_99e99107_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `store_category`
--
ALTER TABLE `store_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `store_order`
--
ALTER TABLE `store_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_order_user_id_ae5f7a5f_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `store_orderitem`
--
ALTER TABLE `store_orderitem`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_orderitem_order_id_acf8722d_fk_store_order_id` (`order_id`),
  ADD KEY `store_orderitem_product_id_f2b098d4_fk_store_product_id` (`product_id`);

--
-- Indexes for table `store_product`
--
ALTER TABLE `store_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_product_category_id_574bae65_fk_store_category_id` (`category_id`);

--
-- Indexes for table `store_profile`
--
ALTER TABLE `store_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `store_wishlist`
--
ALTER TABLE `store_wishlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_wishlist_product_id_8af1333d_fk_store_product_id` (`product_id`),
  ADD KEY `store_wishlist_user_id_afcc4e88_fk_auth_user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `store_cart`
--
ALTER TABLE `store_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `store_category`
--
ALTER TABLE `store_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `store_order`
--
ALTER TABLE `store_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `store_orderitem`
--
ALTER TABLE `store_orderitem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `store_product`
--
ALTER TABLE `store_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `store_profile`
--
ALTER TABLE `store_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `store_wishlist`
--
ALTER TABLE `store_wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `store_cart`
--
ALTER TABLE `store_cart`
  ADD CONSTRAINT `store_cart_product_id_b219c080_fk_store_product_id` FOREIGN KEY (`product_id`) REFERENCES `store_product` (`id`),
  ADD CONSTRAINT `store_cart_user_id_99e99107_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `store_order`
--
ALTER TABLE `store_order`
  ADD CONSTRAINT `store_order_user_id_ae5f7a5f_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `store_orderitem`
--
ALTER TABLE `store_orderitem`
  ADD CONSTRAINT `store_orderitem_order_id_acf8722d_fk_store_order_id` FOREIGN KEY (`order_id`) REFERENCES `store_order` (`id`),
  ADD CONSTRAINT `store_orderitem_product_id_f2b098d4_fk_store_product_id` FOREIGN KEY (`product_id`) REFERENCES `store_product` (`id`);

--
-- Constraints for table `store_product`
--
ALTER TABLE `store_product`
  ADD CONSTRAINT `store_product_category_id_574bae65_fk_store_category_id` FOREIGN KEY (`category_id`) REFERENCES `store_category` (`id`);

--
-- Constraints for table `store_profile`
--
ALTER TABLE `store_profile`
  ADD CONSTRAINT `store_profile_user_id_d67604a1_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `store_wishlist`
--
ALTER TABLE `store_wishlist`
  ADD CONSTRAINT `store_wishlist_product_id_8af1333d_fk_store_product_id` FOREIGN KEY (`product_id`) REFERENCES `store_product` (`id`),
  ADD CONSTRAINT `store_wishlist_user_id_afcc4e88_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
